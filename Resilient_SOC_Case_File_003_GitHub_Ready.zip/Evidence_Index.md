# Evidence Index — Operation Autopilot

| ID | Tool | Screenshot / visible state | What it proves | Related area | Status |
|---|---|---|---|---|---|
| E-01 | TheHive | TheHive case #15, “Hello world”, opened on the timeline. | Case-management workspace is reachable and a case timeline is being inspected. | Case management | CONFIRMED |
| E-02 | TheHive | Repeated timeline view of the same TheHive case. | Supporting duplicate/continuation evidence for case inspection. | Case management | CONFIRMED |
| E-03 | TheHive | Case list showing multiple “Hello world” test cases (#15, #14, #13, #12). | Shows test-case creation/activity in TheHive. | Case management | CONFIRMED |
| E-04 | TheHive | Case #15 detail view with title, severity, TLP/PAP and case metadata. | Confirms a structured TheHive case record. | Case management | CONFIRMED |
| E-05 | TheHive | Continuation of case/timeline inspection. | Supporting case-management evidence. | Case management | CONFIRMED |
| E-06 | TheHive | Case view showing linked-elements area with no linked elements. | Shows the case state at that point; it does not prove downstream linkage. | Case management | CONFIRMED |
| E-07 | Kali / Flask | Terminal running the custom `soar_webhook.py` Flask service on port 5000. | Confirms a local HTTP decision-handler service was started. | Human-in-the-loop | CONFIRMED |
| E-08 | Shuffle | SOC-Auto-Response workflow with a Custom Action, POST method, TheHive-derived body and Bearer authorization. | Confirms workflow/API action configuration. The screenshot visibly shows `body[1].data`; the project files later state `body.0.data` as the intended final mapping. | Dynamic mapping / Cortex | PARTIALLY VERIFIED |
| E-09 | Shuffle | SOC-Auto-Response run details; Cortex_1 returned status 200 and `success: true`. | Confirms successful HTTP-level Cortex action execution for the displayed run. | Cortex integration | CONFIRMED |
| E-10 | Kali / Flask | Terminal shows `approve` being POSTed to the Flask webhook and the Flask service logging receipt/execution. | Confirms the approve branch was exercised at the local webhook layer. | Human-in-the-loop | CONFIRMED |
| E-11 | Shuffle | Another finished SOC-Auto-Response execution with Cortex_1 status 200. | Confirms another workflow execution reached a successful HTTP response. | Cortex integration | CONFIRMED |
| E-12 | Kali / Flask | Flask service output includes approve/reject request activity. | Confirms both decision values were exercised against the local handler. | Human-in-the-loop | CONFIRMED |
| E-13 | Splunk | Windows Security EventCode 4907 search with 10,630 events and latest policy_change_time. | Shows SIEM telemetry used as investigation context. | Detection context | CONFIRMED |
| E-14 | Splunk | Windows Security EventCode 4688 process search for PowerShell/cmd/archive tools; 2,018 events. | Shows endpoint process telemetry available for detection/investigation. | Detection context | CONFIRMED |
| E-15 | Splunk | Sysmon Operational EventCode 11 search for `*.zip`; two results, risk_score 70, alert name `Suspicious Archive Creation`. | Directly shows suspicious archive-creation telemetry and the associated alert fields. | Detection | CONFIRMED |
| E-16 | Kali / Cortex | Cortex job object for IPinfo_1_3 with `data: 8.8.8.8`, organization `Resilient-SOC`, and `status: Success`. | Confirms a successful Cortex job for the IPinfo_1_3 analyzer against 8.8.8.8. | IPinfo analyzer | CONFIRMED |
| E-17 | Splunk | Scheduled-alert page for `SOC - Suspicious Archive Creation` showing no fired events. | Confirms the alert was defined/inspected but was not fired in the displayed state. | Detection validation | CONFIRMED |
| E-18 | TheHive | TheHive case #3, “Hello world”, with no linked elements. | Shows a separate test case used during the lab. | Case management | CONFIRMED |
| E-19 | Shuffle | SOC-Auto-Response webhook configuration displays `Webhook: uninitialized`. | Confirms webhook setup had not yet been initialized. | Webhook troubleshooting | CONFIRMED |
| E-20 | Splunk | Additional Splunk search view. | Supports SIEM-side validation activity; exact query details are not sufficiently legible. | Detection context | PARTIALLY VERIFIED |
| E-21 | Shuffle | Repeat webhook configuration showing the webhook as uninitialized. | Confirms the same webhook initialization problem persisted at that point. | Webhook troubleshooting | CONFIRMED |
| E-22 | TheHive | TheHive case list with test cases. | Shows case source data available for workflow retrieval. | TheHive source | CONFIRMED |
| E-23 | Shuffle | SOC-Auto-Response execution in `EXECUTING` state with Orborus/no-results message. | Shows workflow execution depended on Orborus and had not yet produced results. | Shuffle troubleshooting | CONFIRMED |
| E-24 | Kali / Cortex | Terminal displays TestAnalyzer parameter schema and local `testing.py` file. | Confirms inspection of the local TestAnalyzer implementation. | Analyzer validation | CONFIRMED |
| E-25 | TheHive | TheHive case-creation modal for a test case. | Shows case creation workflow. | Case management | CONFIRMED |
| E-26 | TheHive | TheHive observable list for the test case with a success toast. | Confirms an Observable record was created/visible. | Observable handling | CONFIRMED |
| E-27 | Shuffle | TheHive authentication configuration with instance URL ending `/thehive` and API-key authentication. | Confirms the intended Shuffle → TheHive authentication configuration. | TheHive integration | IMPLEMENTED |
| E-28 | Kali / Docker | Shuffle deployment command and image pull activity. | Confirms self-hosted Shuffle services were deployed/pulled. | Shuffle deployment | CONFIRMED |
| E-29 | Shuffle | Find-your-apps page showing Cases, Intel, Email, SIEM and EDR. | Shows Shuffle app discovery during workflow construction. | Shuffle deployment | CONFIRMED |
| E-30 | Shuffle | Repeat app discovery page. | Supporting workflow-construction evidence. | Shuffle deployment | CONFIRMED |
| E-31 | Shuffle | SOC-Auto-Response workflow canvas with a single `Change Me` node. | Confirms the named workflow existed, but this screenshot alone does not prove the final multi-stage workflow. | Workflow construction | PARTIALLY VERIFIED |
| E-32 | Shuffle | Single `Repeat back to me` action configured with `Hello world`. | Shows an early workflow smoke test rather than the final SOAR chain. | Workflow smoke test | CONFIRMED |
| E-33 | Kali / Cortex + MailHog API | Terminal shows a Mailer responder job with `status: Success` and MailHog API message retrieval. | Supports successful responder execution and inspection of captured mail. | Notification | CONFIRMED |
| E-34 | Kali / Cortex | Terminal traceback includes SMTP `ConnectionRefusedError [Errno 111]` from Mailer code, alongside Cortex job records. | Confirms an intermediate notification failure caused by SMTP connectivity/configuration at that point. | Notification troubleshooting | CONFIRMED |
| E-35 | MailHog | MailHog inbox contains `[Case #1] SOAR Test Case` from the lab sender. | Directly confirms notification email reached the MailHog sink. | Notification | CONFIRMED |
| E-36 | Kali / Docker | Docker stats followed by cloning the Shuffle repository and listing its contents. | Confirms Shuffle source/deployment workspace was present. | Shuffle deployment | CONFIRMED |
| E-37 | Shuffle | Self-hosted Shuffle login screen. | Confirms Shuffle UI was reachable. | Shuffle deployment | CONFIRMED |
| E-38 | Kali / Cortex | Cortex responder API inspection; responder data is returned, followed by `Insufficient rights to perform this action`. | Confirms responder discovery succeeded while a privileged action was rejected. | Cortex authorization | CONFIRMED |
| E-39 | Kali / TheHive | TheHive Cortex configuration PUT returns HTTP 200; logs state `cortex.servers config was updated`. | Confirms TheHive-side Cortex server configuration was updated successfully. | TheHive ↔ Cortex | CONFIRMED |
| E-40 | Kali / Cortex | Terminal exposes credential material while inspecting Cortex/Elasticsearch user data. | Confirms sensitive credential material was exposed during troubleshooting; values are redacted in the publication package. | Security / credential handling | CONFIRMED |
| E-41 | TheHive | TheHive `SOAR Test Case` shows tag `mail=soc01@resilient.local`. | Confirms a case update/tag existed in the displayed case. | TheHive update | CONFIRMED |
| E-42 | Cortex | Responders page lists `Mailer_1_0`, version 1.0, applicable to TheHive case/alert/case task. | Confirms Mailer responder definition is present in Cortex. | Cortex responder | CONFIRMED |
| E-43 | TheHive | Create-case modal is open for a new case. | Shows case creation workflow in the lab. | Case management | CONFIRMED |
| E-44 | TheHive | Add Observable modal is open. | Shows manual Observable creation workflow. | Observable handling | CONFIRMED |
| E-45 | TheHive | Create-case modal populated with `SOAR Test Case`, LOW severity, TLP/PAP clear. | Confirms the SOAR test case was prepared in TheHive. | Case management | CONFIRMED |
| E-46 | TheHive | `SOAR Test Case` Observable view with an IP Observable visible. | Confirms the SOAR test case contains an IP Observable. | Observable handling | CONFIRMED |
| E-47 | Kali / TheHive | Terminal shows TheHive Cortex connector configuration with Bearer key substitution. | Confirms the connector was configured to use Bearer authentication. | TheHive ↔ Cortex | IMPLEMENTED |
| E-48 | Cortex | Jobs History shows three `TestAnalyzer_1_0` jobs: one Success and two Failure. | Confirms repeated TestAnalyzer execution with mixed outcomes. | Analyzer validation | CONFIRMED |
| E-49 | Kali / Cortex | Cortex service log inspection after analyzer tests. | Supports runtime troubleshooting of analyzer execution. | Analyzer troubleshooting | PARTIALLY VERIFIED |
| E-50 | TheHive | TheHive Add User modal with `soc01@resilient.local` and SOC Analyst. | Shows creation/configuration of a TheHive analyst account. | TheHive administration | CONFIRMED |
| E-51 | TheHive | Organization `Resilient` user list contains `SOC Analyst` / `soc01@resilient.local`. | Confirms the analyst user existed in the displayed organization. | TheHive administration | CONFIRMED |
| E-52 | TheHive | TheHive case list is empty at the displayed moment. | Confirms the UI state at that point; it is not evidence of final E2E completion. | Case management | CONFIRMED |
| E-53 | Cortex | Add User modal with login `Resilient`, full name `Resilient SOC`, organization `Resilient-SOC`, roles read/analyze/orgadmin. | Shows Cortex user provisioning in the intended lab organization. | Cortex administration | CONFIRMED |
| E-54 | Cortex | Jobs History again shows one successful and two failed TestAnalyzer_1_0 jobs. | Confirms mixed analyzer outcomes persisted across the displayed history. | Analyzer validation | CONFIRMED |
| E-55 | Kali / Docker | Docker service status and repeated TheHive `/api/status` requests returning 200; Docker daemon status shown active. | Confirms Docker runtime and TheHive status endpoint were reachable. | Infrastructure | CONFIRMED |
| E-56 | Kali / Docker | Repeated TheHive `/api/status` requests returning 200. | Confirms stable status responses during the displayed interval. | Infrastructure | CONFIRMED |
| E-57 | TheHive | TheHive login screen, version 5.7.5-1 visible. | Confirms TheHive UI availability and version branding. | TheHive deployment | CONFIRMED |
| E-58 | Kali / Docker | Docker stats plus `docker compose up -d cortex`; preceding `docker compose ps` attempts show Docker socket permission denied. | Confirms Cortex startup activity and a Docker socket permission problem during troubleshooting. | Infrastructure troubleshooting | CONFIRMED |
| E-59 | Cortex | Create administrator account form. | Shows Cortex administrator provisioning stage. | Cortex deployment | CONFIRMED |
| E-60 | Cortex | Repeat administrator account form. | Supporting Cortex administrator provisioning evidence. | Cortex deployment | CONFIRMED |
| E-61 | Cortex | Organizations page shows the default `cortex` organization active. | Confirms the default Cortex organization existed at this point. | Cortex administration | CONFIRMED |
| E-62 | Cortex | Create organization modal populated with `Resilient-SOC` / `Resilient SOC SOAR Lab`. | Confirms the intended organization was entered for creation; the screenshot alone does not prove Save completed. | Cortex administration | IMPLEMENTED |
| E-63 | Splunk | Splunk host statistics view with large event counts. | Shows the SIEM environment was populated with telemetry. | Detection context | CONFIRMED |
| E-64 | Kali / Docker | `.env` inspection shows Cassandra 4.1.12, Elasticsearch 8.19.20, TheHive 5.7.5, Cortex 4.1.0, Nginx 1.31.4; `docker compose up -d cassandra elasticsearch` pull activity. | Confirms configured versions and dependency startup activity. | Infrastructure | CONFIRMED |
| E-65 | Kali / Docker | `docker compose ps` shows Cassandra and Elasticsearch healthy; TheHive image 5.7.5 being pulled. | Confirms dependency health and TheHive deployment activity. | Infrastructure | CONFIRMED |
| E-66 | Kali / Docker | Docker stats, `docker compose stop thehive`, then `docker compose up -d cortex`. | Shows service lifecycle management during troubleshooting. | Infrastructure | CONFIRMED |
| E-67 | Kali / Docker | Cortex/Play framework logs, `docker compose ps`, Docker stats, then TheHive stop and resource checks. | Supports runtime troubleshooting; it does not independently prove final E2E completion. | Infrastructure | PARTIALLY VERIFIED |