# Commands Reference — Operation Autopilot

> Commands below are derived from the supplied terminal history. Credential values are intentionally redacted.

## Project

```bash
cd ~/resilient-soar
cd ~/resilient-soar/docker/testing
```

## Docker / infrastructure

```bash
docker compose -f docker/testing/docker-compose.yml ps
docker compose -f docker/testing/docker-compose.yml logs --tail=50 cassandra elasticsearch
docker compose up -d cassandra elasticsearch
docker compose up -d thehive
docker compose up -d cortex
docker compose stop thehive
docker compose ps
docker stats --no-stream
```

## TheHive health

```bash
curl -i http://127.0.0.1:9000/thehive/api/status
curl -s -X GET "http://192.168.1.11:9000/thehive/api/v1/case" \
  -H "Authorization: Bearer <REDACTED>"
```

## TheHive → Cortex configuration

```bash
curl -sS -w "\nHTTP %{http_code}\n" \
  -X PUT \
  "http://127.0.0.1:9000/thehive/api/v1/admin/config/cortex" \
  -H "Content-Type: application/json" \
  -H "X-Organisation: admin" \
  -u "admin@thehive.local:<REDACTED>" \
  --data-binary @-
```

The configured Cortex server context was:

```text
http://cortex:9001/cortex
```

with:

```json
{
  "auth": {
    "type": "bearer",
    "key": "<REDACTED>"
  }
}
```

## TheHive Observable query

```bash
curl -s -X POST \
  "http://192.168.1.11:9000/thehive/api/v1/query" \
  -H "Authorization: Bearer <REDACTED>" \
  -H "X-Organisation: Resilient" \
  -H "Content-Type: application/json" \
  --data '{
    "query":[
      {"_name":"getCase","idOrName":"~122884224"},
      {"_name":"observables"}
    ]
  }'
```

## Target-Observable validation

```bash
curl -sS -o /tmp/thehive-query.out -w 'HTTP %{http_code}\n' \
  -X POST \
  "http://192.168.1.11:9000/thehive/api/v1/query" \
  -H "Authorization: Bearer <REDACTED>" \
  -H "X-Organisation: Resilient" \
  -H "Content-Type: application/json" \
  --data '{
    "query":[
      {"_name":"listObservable"},
      {"_name":"filter","_eq":{"_field":"data","_value":"8.8.8.8"}}
    ]
  }'
```

## Cortex analyzer discovery

```bash
curl -s \
  -H "Authorization: Bearer <REDACTED>" \
  "http://127.0.0.1:9001/cortex/api/analyzer?range=all"
```

## TestAnalyzer

Analyzer:

```text
TestAnalyzer_1_0
```

Successful test job referenced by the project:

```text
SmKjYaABXY9xl1BaReUY
```

Job inspection:

```bash
curl -s \
  -H "Authorization: Bearer <REDACTED>" \
  "http://192.168.1.11:9001/cortex/api/job/SmKjYaABXY9xl1BaReUY"
```

## IPinfo compatibility definition

The project history shows a local copy/rename:

```bash
cp ~/resilient-soar/docker/testing/cortex/neurons/analyzers/IPinfo/IPinfo_Details.json \
   ~/resilient-soar/docker/testing/cortex/neurons/analyzers/IPinfo/IPinfo_1_3.json

sed -i 's/"name": "IPinfo_Details"/"name": "IPinfo_1_3"/' \
   ~/resilient-soar/docker/testing/cortex/neurons/analyzers/IPinfo/IPinfo_1_3.json
```

The resulting definition should be documented as:

```text
Lab-local compatibility / alias
```

## IPinfo test request

```bash
curl -s -X POST \
  -H "Authorization: Bearer <REDACTED>" \
  -H "Content-Type: application/json" \
  -d '{"data":"8.8.8.8","dataType":"ip","tlp":2}' \
  "http://127.0.0.1:9001/cortex/api/analyzer/<ANALYZER_ID>/run"
```

## Shuffle dynamic mapping

Intended final project expression:

```text
$thehive_2.body.0.data
```

Important: the supplied screenshot E-08 visibly shows:

```text
$thehive_2.body[1].data
```

Do not silently treat the screenshot and project documentation as identical evidence.

## Flask analyst decision handler

Start:

```bash
python3 soar_webhook.py
```

Approve:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"action":"approve","case_id":"~81928240"}' \
  http://127.0.0.1:5000/api/v1/webhook
```

Reject:

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"action":"reject","case_id":"~81928240"}' \
  http://127.0.0.1:5000/api/v1/webhook
```

## MailHog

Start:

```bash
docker compose up -d mailhog
```

Connectivity test:

```bash
docker compose exec cortex python3 -c '
import socket
s = socket.create_connection(("mailhog", 1025), timeout=5)
print("SMTP CONNECTION SUCCESS")
s.close()
'
```

MailHog API:

```bash
curl -s "http://127.0.0.1:8025/api/v2/messages"
```

## Security rule

Never commit:

```text
CORTEX_API_KEY
THEHIVE_API_KEY
Bearer tokens
passwords
SMTP credentials
webhook secrets
```

Use environment variables or a secret manager.
