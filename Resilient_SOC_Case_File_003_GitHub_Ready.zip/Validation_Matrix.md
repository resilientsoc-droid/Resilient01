# Validation Matrix — Operation Autopilot

| Tool | Test | Expected | Observed | Status | Evidence |
|---|---|---|---|---|---|
| TheHive | UI availability | UI reachable | Visible | CONFIRMED | E-57 |
| TheHive | SOAR case | Case exists | `SOAR Test Case` visible | CONFIRMED | E-45–E-46 |
| TheHive | IP Observable | IP artifact | Visible | CONFIRMED | E-46 |
| TheHive | Cortex connector | Config accepted | HTTP 200 + update log | CONFIRMED | E-39 |
| Shuffle | Workflow | `SOC-Auto-Response` | Visible/runs | CONFIRMED | E-8, E-31 |
| Shuffle | TheHive auth | API key + URL | Configuration visible | IMPLEMENTED | E-27 |
| Shuffle | Cortex action | 200 + success | Shown | CONFIRMED | E-9, E-11 |
| TheHive Query | Case + Observables | JSON returned | Exercised in command history | PARTIALLY VERIFIED | Commands |
| Dynamic mapping | Intended IP | `8.8.8.8` | Final expression documented; screenshot shows `[1]` | PARTIALLY VERIFIED | E-8 |
| Cortex | IPinfo_1_3 | Success for 8.8.8.8 | Success job visible | CONFIRMED | E-16 |
| Cortex | TestAnalyzer | Success | 1 success + 2 failures | CONFIRMED / MIXED | E-48, E-54 |
| HITL | Approve | Decision received | Flask log/test | CONFIRMED | E-10 |
| HITL | Reject | Decision received | Flask log/test | CONFIRMED | E-12 |
| Response | Containment | Simulated | No real action | IMPLEMENTED / NOT PROVEN | E-7 |
| TheHive | Update | Case changed | Mail tag visible | CONFIRMED | E-41 |
| Cortex | Mailer responder | Responder available | `Mailer_1_0` visible | CONFIRMED | E-42 |
| MailHog | Notification | Message received | SOAR email visible | CONFIRMED | E-35 |
| E2E | Single correlated run | Entire chain | Not demonstrated in one continuous run | NOT PROVEN | — |
