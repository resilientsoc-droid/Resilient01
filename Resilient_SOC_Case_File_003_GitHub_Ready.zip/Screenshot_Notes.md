# Screenshot Notes — Operation Autopilot

Each note is bounded by the visible evidence. The screenshots are labeled E-01 through E-67 according to PDF page order.

## E-01 — Figure 1
**Tool:** TheHive
**Visible state/action:** TheHive case #15, “Hello world”, opened on the timeline.
**What it proves:** Case-management workspace is reachable and a case timeline is being inspected.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 1 — TheHive case #15, “Hello world”, opened on the timeline.

## E-02 — Figure 2
**Tool:** TheHive
**Visible state/action:** Repeated timeline view of the same TheHive case.
**What it proves:** Supporting duplicate/continuation evidence for case inspection.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 2 — Repeated timeline view of the same TheHive case.

## E-03 — Figure 3
**Tool:** TheHive
**Visible state/action:** Case list showing multiple “Hello world” test cases (#15, #14, #13, #12).
**What it proves:** Shows test-case creation/activity in TheHive.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 3 — Case list showing multiple “Hello world” test cases (#15, #14, #13, #12).

## E-04 — Figure 4
**Tool:** TheHive
**Visible state/action:** Case #15 detail view with title, severity, TLP/PAP and case metadata.
**What it proves:** Confirms a structured TheHive case record.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 4 — Case #15 detail view with title, severity, TLP/PAP and case metadata.

## E-05 — Figure 5
**Tool:** TheHive
**Visible state/action:** Continuation of case/timeline inspection.
**What it proves:** Supporting case-management evidence.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 5 — Continuation of case/timeline inspection.

## E-06 — Figure 6
**Tool:** TheHive
**Visible state/action:** Case view showing linked-elements area with no linked elements.
**What it proves:** Shows the case state at that point; it does not prove downstream linkage.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 6 — Case view showing linked-elements area with no linked elements.

## E-07 — Figure 7
**Tool:** Kali / Flask
**Visible state/action:** Terminal running the custom `soar_webhook.py` Flask service on port 5000.
**What it proves:** Confirms a local HTTP decision-handler service was started.
**Related section:** Human-in-the-loop
**Evidence level:** **CONFIRMED**
**Caption:** Figure 7 — Terminal running the custom `soar_webhook.py` Flask service on port 5000.

## E-08 — Figure 8
**Tool:** Shuffle
**Visible state/action:** SOC-Auto-Response workflow with a Custom Action, POST method, TheHive-derived body and Bearer authorization.
**What it proves:** Confirms workflow/API action configuration. The screenshot visibly shows `body[1].data`; the project files later state `body.0.data` as the intended final mapping.
**Related section:** Dynamic mapping / Cortex
**Evidence level:** **PARTIALLY VERIFIED**
**Caption:** Figure 8 — SOC-Auto-Response workflow with a Custom Action, POST method, TheHive-derived body and Bearer authorization.

## E-09 — Figure 9
**Tool:** Shuffle
**Visible state/action:** SOC-Auto-Response run details; Cortex_1 returned status 200 and `success: true`.
**What it proves:** Confirms successful HTTP-level Cortex action execution for the displayed run.
**Related section:** Cortex integration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 9 — SOC-Auto-Response run details; Cortex_1 returned status 200 and `success: true`.

## E-10 — Figure 10
**Tool:** Kali / Flask
**Visible state/action:** Terminal shows `approve` being POSTed to the Flask webhook and the Flask service logging receipt/execution.
**What it proves:** Confirms the approve branch was exercised at the local webhook layer.
**Related section:** Human-in-the-loop
**Evidence level:** **CONFIRMED**
**Caption:** Figure 10 — Terminal shows `approve` being POSTed to the Flask webhook and the Flask service logging receipt/execution.

## E-11 — Figure 11
**Tool:** Shuffle
**Visible state/action:** Another finished SOC-Auto-Response execution with Cortex_1 status 200.
**What it proves:** Confirms another workflow execution reached a successful HTTP response.
**Related section:** Cortex integration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 11 — Another finished SOC-Auto-Response execution with Cortex_1 status 200.

## E-12 — Figure 12
**Tool:** Kali / Flask
**Visible state/action:** Flask service output includes approve/reject request activity.
**What it proves:** Confirms both decision values were exercised against the local handler.
**Related section:** Human-in-the-loop
**Evidence level:** **CONFIRMED**
**Caption:** Figure 12 — Flask service output includes approve/reject request activity.

## E-13 — Figure 13
**Tool:** Splunk
**Visible state/action:** Windows Security EventCode 4907 search with 10,630 events and latest policy_change_time.
**What it proves:** Shows SIEM telemetry used as investigation context.
**Related section:** Detection context
**Evidence level:** **CONFIRMED**
**Caption:** Figure 13 — Windows Security EventCode 4907 search with 10,630 events and latest policy_change_time.

## E-14 — Figure 14
**Tool:** Splunk
**Visible state/action:** Windows Security EventCode 4688 process search for PowerShell/cmd/archive tools; 2,018 events.
**What it proves:** Shows endpoint process telemetry available for detection/investigation.
**Related section:** Detection context
**Evidence level:** **CONFIRMED**
**Caption:** Figure 14 — Windows Security EventCode 4688 process search for PowerShell/cmd/archive tools; 2,018 events.

## E-15 — Figure 15
**Tool:** Splunk
**Visible state/action:** Sysmon Operational EventCode 11 search for `*.zip`; two results, risk_score 70, alert name `Suspicious Archive Creation`.
**What it proves:** Directly shows suspicious archive-creation telemetry and the associated alert fields.
**Related section:** Detection
**Evidence level:** **CONFIRMED**
**Caption:** Figure 15 — Sysmon Operational EventCode 11 search for `*.zip`; two results, risk_score 70, alert name `Suspicious Archive Creation`.

## E-16 — Figure 16
**Tool:** Kali / Cortex
**Visible state/action:** Cortex job object for IPinfo_1_3 with `data: 8.8.8.8`, organization `Resilient-SOC`, and `status: Success`.
**What it proves:** Confirms a successful Cortex job for the IPinfo_1_3 analyzer against 8.8.8.8.
**Related section:** IPinfo analyzer
**Evidence level:** **CONFIRMED**
**Caption:** Figure 16 — Cortex job object for IPinfo_1_3 with `data: 8.8.8.8`, organization `Resilient-SOC`, and `status: Success`.

## E-17 — Figure 17
**Tool:** Splunk
**Visible state/action:** Scheduled-alert page for `SOC - Suspicious Archive Creation` showing no fired events.
**What it proves:** Confirms the alert was defined/inspected but was not fired in the displayed state.
**Related section:** Detection validation
**Evidence level:** **CONFIRMED**
**Caption:** Figure 17 — Scheduled-alert page for `SOC - Suspicious Archive Creation` showing no fired events.

## E-18 — Figure 18
**Tool:** TheHive
**Visible state/action:** TheHive case #3, “Hello world”, with no linked elements.
**What it proves:** Shows a separate test case used during the lab.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 18 — TheHive case #3, “Hello world”, with no linked elements.

## E-19 — Figure 19
**Tool:** Shuffle
**Visible state/action:** SOC-Auto-Response webhook configuration displays `Webhook: uninitialized`.
**What it proves:** Confirms webhook setup had not yet been initialized.
**Related section:** Webhook troubleshooting
**Evidence level:** **CONFIRMED**
**Caption:** Figure 19 — SOC-Auto-Response webhook configuration displays `Webhook: uninitialized`.

## E-20 — Figure 20
**Tool:** Splunk
**Visible state/action:** Additional Splunk search view.
**What it proves:** Supports SIEM-side validation activity; exact query details are not sufficiently legible.
**Related section:** Detection context
**Evidence level:** **PARTIALLY VERIFIED**
**Caption:** Figure 20 — Additional Splunk search view.

## E-21 — Figure 21
**Tool:** Shuffle
**Visible state/action:** Repeat webhook configuration showing the webhook as uninitialized.
**What it proves:** Confirms the same webhook initialization problem persisted at that point.
**Related section:** Webhook troubleshooting
**Evidence level:** **CONFIRMED**
**Caption:** Figure 21 — Repeat webhook configuration showing the webhook as uninitialized.

## E-22 — Figure 22
**Tool:** TheHive
**Visible state/action:** TheHive case list with test cases.
**What it proves:** Shows case source data available for workflow retrieval.
**Related section:** TheHive source
**Evidence level:** **CONFIRMED**
**Caption:** Figure 22 — TheHive case list with test cases.

## E-23 — Figure 23
**Tool:** Shuffle
**Visible state/action:** SOC-Auto-Response execution in `EXECUTING` state with Orborus/no-results message.
**What it proves:** Shows workflow execution depended on Orborus and had not yet produced results.
**Related section:** Shuffle troubleshooting
**Evidence level:** **CONFIRMED**
**Caption:** Figure 23 — SOC-Auto-Response execution in `EXECUTING` state with Orborus/no-results message.

## E-24 — Figure 24
**Tool:** Kali / Cortex
**Visible state/action:** Terminal displays TestAnalyzer parameter schema and local `testing.py` file.
**What it proves:** Confirms inspection of the local TestAnalyzer implementation.
**Related section:** Analyzer validation
**Evidence level:** **CONFIRMED**
**Caption:** Figure 24 — Terminal displays TestAnalyzer parameter schema and local `testing.py` file.

## E-25 — Figure 25
**Tool:** TheHive
**Visible state/action:** TheHive case-creation modal for a test case.
**What it proves:** Shows case creation workflow.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 25 — TheHive case-creation modal for a test case.

## E-26 — Figure 26
**Tool:** TheHive
**Visible state/action:** TheHive observable list for the test case with a success toast.
**What it proves:** Confirms an Observable record was created/visible.
**Related section:** Observable handling
**Evidence level:** **CONFIRMED**
**Caption:** Figure 26 — TheHive observable list for the test case with a success toast.

## E-27 — Figure 27
**Tool:** Shuffle
**Visible state/action:** TheHive authentication configuration with instance URL ending `/thehive` and API-key authentication.
**What it proves:** Confirms the intended Shuffle → TheHive authentication configuration.
**Related section:** TheHive integration
**Evidence level:** **IMPLEMENTED**
**Caption:** Figure 27 — TheHive authentication configuration with instance URL ending `/thehive` and API-key authentication.

## E-28 — Figure 28
**Tool:** Kali / Docker
**Visible state/action:** Shuffle deployment command and image pull activity.
**What it proves:** Confirms self-hosted Shuffle services were deployed/pulled.
**Related section:** Shuffle deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 28 — Shuffle deployment command and image pull activity.

## E-29 — Figure 29
**Tool:** Shuffle
**Visible state/action:** Find-your-apps page showing Cases, Intel, Email, SIEM and EDR.
**What it proves:** Shows Shuffle app discovery during workflow construction.
**Related section:** Shuffle deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 29 — Find-your-apps page showing Cases, Intel, Email, SIEM and EDR.

## E-30 — Figure 30
**Tool:** Shuffle
**Visible state/action:** Repeat app discovery page.
**What it proves:** Supporting workflow-construction evidence.
**Related section:** Shuffle deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 30 — Repeat app discovery page.

## E-31 — Figure 31
**Tool:** Shuffle
**Visible state/action:** SOC-Auto-Response workflow canvas with a single `Change Me` node.
**What it proves:** Confirms the named workflow existed, but this screenshot alone does not prove the final multi-stage workflow.
**Related section:** Workflow construction
**Evidence level:** **PARTIALLY VERIFIED**
**Caption:** Figure 31 — SOC-Auto-Response workflow canvas with a single `Change Me` node.

## E-32 — Figure 32
**Tool:** Shuffle
**Visible state/action:** Single `Repeat back to me` action configured with `Hello world`.
**What it proves:** Shows an early workflow smoke test rather than the final SOAR chain.
**Related section:** Workflow smoke test
**Evidence level:** **CONFIRMED**
**Caption:** Figure 32 — Single `Repeat back to me` action configured with `Hello world`.

## E-33 — Figure 33
**Tool:** Kali / Cortex + MailHog API
**Visible state/action:** Terminal shows a Mailer responder job with `status: Success` and MailHog API message retrieval.
**What it proves:** Supports successful responder execution and inspection of captured mail.
**Related section:** Notification
**Evidence level:** **CONFIRMED**
**Caption:** Figure 33 — Terminal shows a Mailer responder job with `status: Success` and MailHog API message retrieval.

## E-34 — Figure 34
**Tool:** Kali / Cortex
**Visible state/action:** Terminal traceback includes SMTP `ConnectionRefusedError [Errno 111]` from Mailer code, alongside Cortex job records.
**What it proves:** Confirms an intermediate notification failure caused by SMTP connectivity/configuration at that point.
**Related section:** Notification troubleshooting
**Evidence level:** **CONFIRMED**
**Caption:** Figure 34 — Terminal traceback includes SMTP `ConnectionRefusedError [Errno 111]` from Mailer code, alongside Cortex job records.

## E-35 — Figure 35
**Tool:** MailHog
**Visible state/action:** MailHog inbox contains `[Case #1] SOAR Test Case` from the lab sender.
**What it proves:** Directly confirms notification email reached the MailHog sink.
**Related section:** Notification
**Evidence level:** **CONFIRMED**
**Caption:** Figure 35 — MailHog inbox contains `[Case #1] SOAR Test Case` from the lab sender.

## E-36 — Figure 36
**Tool:** Kali / Docker
**Visible state/action:** Docker stats followed by cloning the Shuffle repository and listing its contents.
**What it proves:** Confirms Shuffle source/deployment workspace was present.
**Related section:** Shuffle deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 36 — Docker stats followed by cloning the Shuffle repository and listing its contents.

## E-37 — Figure 37
**Tool:** Shuffle
**Visible state/action:** Self-hosted Shuffle login screen.
**What it proves:** Confirms Shuffle UI was reachable.
**Related section:** Shuffle deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 37 — Self-hosted Shuffle login screen.

## E-38 — Figure 38
**Tool:** Kali / Cortex
**Visible state/action:** Cortex responder API inspection; responder data is returned, followed by `Insufficient rights to perform this action`.
**What it proves:** Confirms responder discovery succeeded while a privileged action was rejected.
**Related section:** Cortex authorization
**Evidence level:** **CONFIRMED**
**Caption:** Figure 38 — Cortex responder API inspection; responder data is returned, followed by `Insufficient rights to perform this action`.

## E-39 — Figure 39
**Tool:** Kali / TheHive
**Visible state/action:** TheHive Cortex configuration PUT returns HTTP 200; logs state `cortex.servers config was updated`.
**What it proves:** Confirms TheHive-side Cortex server configuration was updated successfully.
**Related section:** TheHive ↔ Cortex
**Evidence level:** **CONFIRMED**
**Caption:** Figure 39 — TheHive Cortex configuration PUT returns HTTP 200; logs state `cortex.servers config was updated`.

## E-40 — Figure 40
**Tool:** Kali / Cortex
**Visible state/action:** Terminal exposes credential material while inspecting Cortex/Elasticsearch user data.
**What it proves:** Confirms sensitive credential material was exposed during troubleshooting; values are redacted in the publication package.
**Related section:** Security / credential handling
**Evidence level:** **CONFIRMED**
**Caption:** Figure 40 — Terminal exposes credential material while inspecting Cortex/Elasticsearch user data.

## E-41 — Figure 41
**Tool:** TheHive
**Visible state/action:** TheHive `SOAR Test Case` shows tag `mail=soc01@resilient.local`.
**What it proves:** Confirms a case update/tag existed in the displayed case.
**Related section:** TheHive update
**Evidence level:** **CONFIRMED**
**Caption:** Figure 41 — TheHive `SOAR Test Case` shows tag `mail=soc01@resilient.local`.

## E-42 — Figure 42
**Tool:** Cortex
**Visible state/action:** Responders page lists `Mailer_1_0`, version 1.0, applicable to TheHive case/alert/case task.
**What it proves:** Confirms Mailer responder definition is present in Cortex.
**Related section:** Cortex responder
**Evidence level:** **CONFIRMED**
**Caption:** Figure 42 — Responders page lists `Mailer_1_0`, version 1.0, applicable to TheHive case/alert/case task.

## E-43 — Figure 43
**Tool:** TheHive
**Visible state/action:** Create-case modal is open for a new case.
**What it proves:** Shows case creation workflow in the lab.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 43 — Create-case modal is open for a new case.

## E-44 — Figure 44
**Tool:** TheHive
**Visible state/action:** Add Observable modal is open.
**What it proves:** Shows manual Observable creation workflow.
**Related section:** Observable handling
**Evidence level:** **CONFIRMED**
**Caption:** Figure 44 — Add Observable modal is open.

## E-45 — Figure 45
**Tool:** TheHive
**Visible state/action:** Create-case modal populated with `SOAR Test Case`, LOW severity, TLP/PAP clear.
**What it proves:** Confirms the SOAR test case was prepared in TheHive.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 45 — Create-case modal populated with `SOAR Test Case`, LOW severity, TLP/PAP clear.

## E-46 — Figure 46
**Tool:** TheHive
**Visible state/action:** `SOAR Test Case` Observable view with an IP Observable visible.
**What it proves:** Confirms the SOAR test case contains an IP Observable.
**Related section:** Observable handling
**Evidence level:** **CONFIRMED**
**Caption:** Figure 46 — `SOAR Test Case` Observable view with an IP Observable visible.

## E-47 — Figure 47
**Tool:** Kali / TheHive
**Visible state/action:** Terminal shows TheHive Cortex connector configuration with Bearer key substitution.
**What it proves:** Confirms the connector was configured to use Bearer authentication.
**Related section:** TheHive ↔ Cortex
**Evidence level:** **IMPLEMENTED**
**Caption:** Figure 47 — Terminal shows TheHive Cortex connector configuration with Bearer key substitution.

## E-48 — Figure 48
**Tool:** Cortex
**Visible state/action:** Jobs History shows three `TestAnalyzer_1_0` jobs: one Success and two Failure.
**What it proves:** Confirms repeated TestAnalyzer execution with mixed outcomes.
**Related section:** Analyzer validation
**Evidence level:** **CONFIRMED**
**Caption:** Figure 48 — Jobs History shows three `TestAnalyzer_1_0` jobs: one Success and two Failure.

## E-49 — Figure 49
**Tool:** Kali / Cortex
**Visible state/action:** Cortex service log inspection after analyzer tests.
**What it proves:** Supports runtime troubleshooting of analyzer execution.
**Related section:** Analyzer troubleshooting
**Evidence level:** **PARTIALLY VERIFIED**
**Caption:** Figure 49 — Cortex service log inspection after analyzer tests.

## E-50 — Figure 50
**Tool:** TheHive
**Visible state/action:** TheHive Add User modal with `soc01@resilient.local` and SOC Analyst.
**What it proves:** Shows creation/configuration of a TheHive analyst account.
**Related section:** TheHive administration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 50 — TheHive Add User modal with `soc01@resilient.local` and SOC Analyst.

## E-51 — Figure 51
**Tool:** TheHive
**Visible state/action:** Organization `Resilient` user list contains `SOC Analyst` / `soc01@resilient.local`.
**What it proves:** Confirms the analyst user existed in the displayed organization.
**Related section:** TheHive administration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 51 — Organization `Resilient` user list contains `SOC Analyst` / `soc01@resilient.local`.

## E-52 — Figure 52
**Tool:** TheHive
**Visible state/action:** TheHive case list is empty at the displayed moment.
**What it proves:** Confirms the UI state at that point; it is not evidence of final E2E completion.
**Related section:** Case management
**Evidence level:** **CONFIRMED**
**Caption:** Figure 52 — TheHive case list is empty at the displayed moment.

## E-53 — Figure 53
**Tool:** Cortex
**Visible state/action:** Add User modal with login `Resilient`, full name `Resilient SOC`, organization `Resilient-SOC`, roles read/analyze/orgadmin.
**What it proves:** Shows Cortex user provisioning in the intended lab organization.
**Related section:** Cortex administration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 53 — Add User modal with login `Resilient`, full name `Resilient SOC`, organization `Resilient-SOC`, roles read/analyze/orgadmin.

## E-54 — Figure 54
**Tool:** Cortex
**Visible state/action:** Jobs History again shows one successful and two failed TestAnalyzer_1_0 jobs.
**What it proves:** Confirms mixed analyzer outcomes persisted across the displayed history.
**Related section:** Analyzer validation
**Evidence level:** **CONFIRMED**
**Caption:** Figure 54 — Jobs History again shows one successful and two failed TestAnalyzer_1_0 jobs.

## E-55 — Figure 55
**Tool:** Kali / Docker
**Visible state/action:** Docker service status and repeated TheHive `/api/status` requests returning 200; Docker daemon status shown active.
**What it proves:** Confirms Docker runtime and TheHive status endpoint were reachable.
**Related section:** Infrastructure
**Evidence level:** **CONFIRMED**
**Caption:** Figure 55 — Docker service status and repeated TheHive `/api/status` requests returning 200; Docker daemon status shown active.

## E-56 — Figure 56
**Tool:** Kali / Docker
**Visible state/action:** Repeated TheHive `/api/status` requests returning 200.
**What it proves:** Confirms stable status responses during the displayed interval.
**Related section:** Infrastructure
**Evidence level:** **CONFIRMED**
**Caption:** Figure 56 — Repeated TheHive `/api/status` requests returning 200.

## E-57 — Figure 57
**Tool:** TheHive
**Visible state/action:** TheHive login screen, version 5.7.5-1 visible.
**What it proves:** Confirms TheHive UI availability and version branding.
**Related section:** TheHive deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 57 — TheHive login screen, version 5.7.5-1 visible.

## E-58 — Figure 58
**Tool:** Kali / Docker
**Visible state/action:** Docker stats plus `docker compose up -d cortex`; preceding `docker compose ps` attempts show Docker socket permission denied.
**What it proves:** Confirms Cortex startup activity and a Docker socket permission problem during troubleshooting.
**Related section:** Infrastructure troubleshooting
**Evidence level:** **CONFIRMED**
**Caption:** Figure 58 — Docker stats plus `docker compose up -d cortex`; preceding `docker compose ps` attempts show Docker socket permission denied.

## E-59 — Figure 59
**Tool:** Cortex
**Visible state/action:** Create administrator account form.
**What it proves:** Shows Cortex administrator provisioning stage.
**Related section:** Cortex deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 59 — Create administrator account form.

## E-60 — Figure 60
**Tool:** Cortex
**Visible state/action:** Repeat administrator account form.
**What it proves:** Supporting Cortex administrator provisioning evidence.
**Related section:** Cortex deployment
**Evidence level:** **CONFIRMED**
**Caption:** Figure 60 — Repeat administrator account form.

## E-61 — Figure 61
**Tool:** Cortex
**Visible state/action:** Organizations page shows the default `cortex` organization active.
**What it proves:** Confirms the default Cortex organization existed at this point.
**Related section:** Cortex administration
**Evidence level:** **CONFIRMED**
**Caption:** Figure 61 — Organizations page shows the default `cortex` organization active.

## E-62 — Figure 62
**Tool:** Cortex
**Visible state/action:** Create organization modal populated with `Resilient-SOC` / `Resilient SOC SOAR Lab`.
**What it proves:** Confirms the intended organization was entered for creation; the screenshot alone does not prove Save completed.
**Related section:** Cortex administration
**Evidence level:** **IMPLEMENTED**
**Caption:** Figure 62 — Create organization modal populated with `Resilient-SOC` / `Resilient SOC SOAR Lab`.

## E-63 — Figure 63
**Tool:** Splunk
**Visible state/action:** Splunk host statistics view with large event counts.
**What it proves:** Shows the SIEM environment was populated with telemetry.
**Related section:** Detection context
**Evidence level:** **CONFIRMED**
**Caption:** Figure 63 — Splunk host statistics view with large event counts.

## E-64 — Figure 64
**Tool:** Kali / Docker
**Visible state/action:** `.env` inspection shows Cassandra 4.1.12, Elasticsearch 8.19.20, TheHive 5.7.5, Cortex 4.1.0, Nginx 1.31.4; `docker compose up -d cassandra elasticsearch` pull activity.
**What it proves:** Confirms configured versions and dependency startup activity.
**Related section:** Infrastructure
**Evidence level:** **CONFIRMED**
**Caption:** Figure 64 — `.env` inspection shows Cassandra 4.1.12, Elasticsearch 8.19.20, TheHive 5.7.5, Cortex 4.1.0, Nginx 1.31.4; `docker compose up -d cassandra elasticsearch` pull activity.

## E-65 — Figure 65
**Tool:** Kali / Docker
**Visible state/action:** `docker compose ps` shows Cassandra and Elasticsearch healthy; TheHive image 5.7.5 being pulled.
**What it proves:** Confirms dependency health and TheHive deployment activity.
**Related section:** Infrastructure
**Evidence level:** **CONFIRMED**
**Caption:** Figure 65 — `docker compose ps` shows Cassandra and Elasticsearch healthy; TheHive image 5.7.5 being pulled.

## E-66 — Figure 66
**Tool:** Kali / Docker
**Visible state/action:** Docker stats, `docker compose stop thehive`, then `docker compose up -d cortex`.
**What it proves:** Shows service lifecycle management during troubleshooting.
**Related section:** Infrastructure
**Evidence level:** **CONFIRMED**
**Caption:** Figure 66 — Docker stats, `docker compose stop thehive`, then `docker compose up -d cortex`.

## E-67 — Figure 67
**Tool:** Kali / Docker
**Visible state/action:** Cortex/Play framework logs, `docker compose ps`, Docker stats, then TheHive stop and resource checks.
**What it proves:** Supports runtime troubleshooting; it does not independently prove final E2E completion.
**Related section:** Infrastructure
**Evidence level:** **PARTIALLY VERIFIED**
**Caption:** Figure 67 — Cortex/Play framework logs, `docker compose ps`, Docker stats, then TheHive stop and resource checks.
