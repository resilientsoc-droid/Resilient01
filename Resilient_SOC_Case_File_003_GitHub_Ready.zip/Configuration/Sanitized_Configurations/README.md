# Sanitized Configuration Policy

Use placeholders such as:

- `<REDACTED>`
- `<CORTEX_API_KEY>`
- `<THEHIVE_API_KEY>`

Do not publish real keys, passwords, bearer tokens, SMTP credentials, or webhook secrets.
