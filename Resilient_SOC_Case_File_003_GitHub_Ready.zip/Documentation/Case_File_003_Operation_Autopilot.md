# Resilient SOC Case File #003 — Operation Autopilot
## From Detection to Automated Response: SOAR Integration Lab

**Team:** Resilient SOC  
**Case File:** #003  
**Operation:** Autopilot  
**Date:** 03 September 2026  
**Environment:** Kali Linux / Docker / TheHive / Cortex / Shuffle

> **Evidence policy:** This document distinguishes what is directly demonstrated by the supplied evidence from what is only implemented/configured or inferred from project history. No successful result is claimed solely because a workflow was designed to produce it.

## 1. Executive Summary

Operation Autopilot is a defensive SOAR integration lab connecting TheHive, Cortex, Shuffle, a small Flask-based analyst-decision handler, and MailHog. The lab also uses Docker-based infrastructure with Cassandra and Elasticsearch, with Nginx present in the environment.

The intended operational chain is:

```text
TheHive Case
→ Observable
→ Shuffle
→ TheHive Query
→ Observable Retrieval
→ Dynamic Mapping
→ Cortex
→ Analyzer
→ Analysis
→ Human Analyst Decision
→ Simulated Response
→ TheHive Update
→ Notification
```

The supplied evidence demonstrates several strong component-level results:

- TheHive cases and IP Observables were created and inspected.
- Shuffle's `SOC-Auto-Response` workflow was created and executed.
- Shuffle's TheHive authentication configuration was established.
- TheHive's Cortex connector configuration was updated with HTTP 200 and an update log.
- Cortex analyzer jobs were executed.
- A Cortex `IPinfo_1_3` job is shown as `Success` for `8.8.8.8`.
- `TestAnalyzer_1_0` shows both successful and failed executions.
- `Mailer_1_0` is visible in Cortex and a MailHog message is visible.
- A custom Flask webhook received both `approve` and `reject` test requests.
- TheHive contains a visible `mail=soc01@resilient.local` case tag.

At the same time, the evidence exposes important validation gaps. The screenshot showing the Shuffle Cortex body visibly uses `body[1].data`, while the project documentation identifies `$thehive_2.body.0.data` as the intended final expression. The supplied material therefore proves that dynamic mapping was actively developed and tested, but does not provide a screenshot that independently proves the final `[0]` mapping in the same execution as the successful Cortex job.

Similarly, the evidence proves individual stages, but not one continuous, correlation-preserving E2E execution from `8.8.8.8` through analyst decision, simulated response, TheHive update, and notification.

**Overall assessment: IMPLEMENTED with strong component-level validation and PARTIAL E2E verification.**

## 2. Objectives

### 2.1 Primary objective

Build a lab-scale SOAR workflow that connects case management, Observable retrieval, enrichment, orchestration, analyst decision-making, simulated response, case tracking, and notification.

### 2.2 Technical objectives

1. Deploy the required Docker services.
2. Validate TheHive availability and case handling.
3. Create and manage IP Observables.
4. Integrate TheHive with Cortex.
5. Validate Cortex API authentication and context.
6. Validate analyzer execution.
7. Investigate the requested `IPinfo_1_3` analyzer.
8. Deploy Shuffle and construct `SOC-Auto-Response`.
9. Retrieve TheHive Observables through `/thehive/api/v1/query`.
10. Map the returned JSON into a Cortex request.
11. Exercise human approval and rejection paths.
12. Simulate containment/escalation rather than execute real production response.
13. Update the TheHive case.
14. Validate lab notification through MailHog.
15. Preserve troubleshooting evidence.

## 3. Environment

| Tool | Version / Context | Role | Endpoint |
|---|---|---|---|
| Kali Linux | Host OS | Administration / testing | Host |
| Docker | 28.5.2+dfsg4 | Container runtime | Host |
| Docker Compose | 2.40.3-3 | Service orchestration | Host |
| TheHive | 5.7.5 | Case + Observable management | `http://192.168.1.11:9000` |
| Cortex | 4.1.0 | Analyzer / responder execution | `http://192.168.1.11:9001/cortex` |
| Elasticsearch | 8.19.20 | Cortex/TheHive dependency | Internal |
| Cassandra | 4.1.12 | TheHive dependency | Internal |
| Shuffle | Lab deployment | SOAR orchestration | `http://192.168.1.11:3001` |
| Nginx | 1.31.4 shown in `.env` evidence | Web/proxy component | Lab |
| MailHog | Lab deployment | SMTP sink / notification validation | 1025 / 8025 |
| Flask | Custom `soar_webhook.py` | Analyst decision handler | `127.0.0.1:5000` |

## 4. Architecture

![Architecture](architecture.png)

The architectural boundary is deliberate:

- **TheHive:** system of record for cases and Observables.
- **Shuffle:** workflow/orchestration layer.
- **Cortex:** analysis/enrichment execution.
- **Flask webhook:** analyst decision boundary used in the lab.
- **Response:** simulated to prevent unintended production-side changes.
- **MailHog:** isolated notification sink.

## 5. TheHive Deployment & Configuration

The evidence shows TheHive 5.7.5 was reachable and used for multiple test cases. The SOAR test case was created with LOW severity and clear TLP/PAP values, and an IP Observable was subsequently visible in the case.

The project command history also shows repeated validation of:

```text
/thehive/api/status
```

with HTTP 200 responses.

The TheHive → Cortex connector was configured using the Cortex context:

```text
http://cortex:9001/cortex
```

with Bearer authentication. A later configuration update returned HTTP 200 and produced:

```text
cortex.servers config was updated
```

This is direct evidence that the TheHive-side Cortex configuration was accepted by the application.

**Evidence:** E-39, E-41, E-45, E-46, E-55–E-57.

## 6. Cortex Deployment & Configuration

Cortex 4.1.0 was used as the analysis platform. The project history shows extensive troubleshooting around:

- API context paths,
- authentication headers,
- local user/key discovery,
- analyzer inventory,
- organization context,
- job execution,
- worker execution,
- responder permissions.

The configured API context is:

```text
http://192.168.1.11:9001/cortex
```

The workflow uses:

```http
Authorization: Bearer <REDACTED>
```

The terminal evidence also shows that credential material was temporarily exposed during troubleshooting. This is treated as a security finding in this documentation, not as something to publish.

**Evidence:** E-38–E-40, E-47, E-53, E-59–E-62.

## 7. Cortex Analyzer Validation

### 7.1 TestAnalyzer_1_0

`TestAnalyzer_1_0` was used to validate the analyzer execution path.

The Cortex job history shows:

- one successful job,
- two failed jobs.

This mixed outcome is important. It proves that the analyzer execution path was exercised, but it does not justify describing the analyzer as universally healthy.

A successful job ID supplied in the project material is:

```text
SmKjYaABXY9xl1BaReUY
```

**Evidence:** E-16, E-24, E-48, E-54.

### 7.2 Interpretation

**CONFIRMED:** Cortex can execute TestAnalyzer jobs.  
**CONFIRMED:** At least one TestAnalyzer execution succeeded.  
**CONFIRMED:** Other TestAnalyzer executions failed.  
**NOT PROVEN:** 100% execution reliability.

## 8. IPinfo Analyzer Investigation

The requested analyzer was:

```text
IPinfo_1_3
```

The project command history shows that the existing local IPinfo definition was inspected and then copied:

```bash
cp .../IPinfo_Details.json .../IPinfo_1_3.json
sed -i 's/"name": "IPinfo_Details"/"name": "IPinfo_1_3"/' ...
```

This is significant: the evidence supports describing `IPinfo_1_3` as a **lab-local compatibility / alias definition**, not as an official upstream analyzer.

The Cortex job evidence then shows an `IPinfo_1_3` execution with:

```text
data: 8.8.8.8
status: Success
organization: Resilient-SOC
```

The corresponding analyzer definition ID shown in the terminal evidence is:

```text
IPinfo_1_3_1_0
```

**Conclusion:** the lab-local IPinfo compatibility definition was successfully exercised against the target IP at the Cortex job level.

**Evidence:** E-16 and the corresponding project command history; supporting analyzer inspection evidence E-63.

## 9. Shuffle Deployment

Shuffle was deployed as the orchestration layer. The evidence shows:

- source/deployment workspace,
- service image pulls,
- Shuffle UI availability,
- app discovery,
- workflow creation,
- workflow execution,
- Orborus dependency troubleshooting.

The intended workflow is:

```text
SOC-Auto-Response
```

The evidence also captures an early workflow smoke test using:

```text
Repeat back to me
Hello world
```

That early workflow should not be confused with the later SOAR integration workflow.

**Evidence:** E-23, E-28–E-32, E-36–E-37.

## 10. Shuffle → TheHive Integration

Shuffle's TheHive authentication configuration specifies the TheHive instance and API-key authentication model.

The integration endpoint is represented in the lab as:

```text
http://192.168.1.11:9000/thehive
```

The project history also shows API requests to the TheHive `/api/v1` namespace using Bearer authentication.

**Status:** IMPLEMENTED / EXERCISED.

**Evidence:** E-27, E-39, E-47.

## 11. TheHive Observable Retrieval

The core TheHive query is:

```json
{
  "query": [
    {
      "_name": "getCase",
      "idOrName": "~122884224"
    },
    {
      "_name": "observables"
    }
  ]
}
```

Endpoint:

```text
/thehive/api/v1/query
```

The project command history also shows direct validation of the case and its Observables, including a query specifically filtering for:

```text
8.8.8.8
```

The evidence demonstrates that the workflow was designed around retrieving Observables from TheHive rather than hard-coding the final Cortex input.

## 12. Dynamic Observable Mapping

This is the key integration issue in the case.

### 12.1 Initial mapping problem

The workflow had to transform TheHive's structured response into the scalar `data` value expected by Cortex.

The project history records an empty input state:

```text
data: ""
```

The debugging process then inspected the actual JSON structure and introduced an indexed path.

### 12.2 Evidence discrepancy

The screenshot of the Shuffle Cortex Custom Action visibly shows:

```text
$thehive_2.body[1].data
```

while the project documentation identifies the intended final expression as:

```text
$thehive_2.body.0.data
```

This difference must be preserved rather than silently reconciled.

### 12.3 Final documented expression

```text
$thehive_2.body.0.data
```

Example target value:

```text
8.8.8.8
```

### 12.4 Observable indexing

The project notes that TheHive query results can contain multiple Observables, including:

```text
1.1.1.1
8.8.8.8
```

Therefore, the index is execution-dependent.

A production-quality implementation should select the Observable using its attributes or explicitly validate:

```text
datatype == ip
AND
data == expected value
```

before sending it to Cortex.

### 12.5 Evidence classification

**IMPLEMENTED:** dynamic mapping concept and final documented expression.  
**PARTIALLY VERIFIED:** screenshot evidence does not independently prove that `[0]` was the exact mapping used in the successful IPinfo run.  
**CONFIRMED:** Cortex successfully received `8.8.8.8` in a direct analyzer job.

## 13. Cortex_1 Integration

Shuffle's `Cortex_1` action uses a POST request against the Cortex API context.

The displayed workflow execution shows:

```text
status: 200
success: true
```

The workflow therefore demonstrated successful HTTP-level interaction with Cortex.

Important distinction:

```text
HTTP 200
≠
validated semantic enrichment result
```

The result body must still be correlated to the exact input Observable and job ID.

**Evidence:** E-9 and E-11.

## 14. Cortex Job / Analysis Result

The project history shows multiple Cortex job queries and report retrieval attempts.

The strongest direct IPinfo evidence is the successful job object showing:

```text
analyzerName: IPinfo_1_3
data: 8.8.8.8
status: Success
```

The TestAnalyzer history separately shows mixed success/failure outcomes.

This establishes:

```text
Cortex
→ Analyzer
→ Job
```

but the supplied screenshots do not provide a single continuous identifier connecting that exact job to a specific Shuffle execution and subsequent analyst decision.

## 15. Human-in-the-Loop

The lab uses a custom Flask service:

```text
soar_webhook.py
```

running on port 5000.

The command history shows explicit tests for:

```json
{"action":"approve"}
```

and:

```json
{"action":"reject"}
```

including case IDs such as:

```text
~81928240
```

The terminal evidence shows the service receiving and processing the decision values.

This validates the **decision-handler layer**.

It does not, by itself, prove that every Shuffle execution was paused and resumed through this webhook in a single E2E transaction.

**Evidence:** E-7, E-10, E-12.

## 16. Response Simulation

The logical response branch is:

```text
Approve → Simulated Containment
Reject  → Escalation
```

No evidence demonstrates a real endpoint isolation, firewall block, account disablement, or other production containment action.

That is the correct behavior for a lab: response authority remains simulated.

**Status:** IMPLEMENTED as a lab design; real containment NOT PROVEN.

## 17. TheHive Update

The TheHive `SOAR Test Case` visibly contains:

```text
mail=soc01@resilient.local
```

as a case tag.

The project command history also shows direct tag/update API calls.

This confirms that a TheHive case update was performed.

The evidence does not prove that this update occurred immediately after the exact successful Cortex job in one continuous E2E execution.

**Status:** CONFIRMED case update; PARTIALLY VERIFIED as a correlated E2E stage.

**Evidence:** E-41.

## 18. Notification

Cortex exposes:

```text
Mailer_1_0
```

as a responder.

The project history shows MailHog deployment and SMTP connectivity testing. An intermediate failure is also visible:

```text
ConnectionRefusedError [Errno 111] Connection refused
```

Later evidence shows a Mailer responder job with `Success`, and the MailHog UI contains:

```text
[Case #1] SOAR Test Case
```

Therefore:

**CONFIRMED:** a lab notification reached MailHog.

**NOT PROVEN:** delivery to an external production mail system.

**Evidence:** E-33–E-35, E-42.

## 19. End-to-End Validation

### Evidence chain

```text
TheHive Case
→ Observable
→ Shuffle
→ TheHive Query
→ Dynamic Mapping
→ Cortex
→ Analyzer
→ Analysis
→ Human Decision
→ Response Simulation
→ TheHive Update
→ Notification
```

### Current evidence position

| Stage | Evidence position |
|---|---|
| TheHive Case | CONFIRMED |
| IP Observable | CONFIRMED |
| Shuffle workflow | CONFIRMED / PARTIAL final-state proof |
| TheHive API integration | IMPLEMENTED / EXERCISED |
| Observable query | IMPLEMENTED / EXERCISED |
| Dynamic mapping | PARTIALLY VERIFIED |
| Cortex HTTP request | CONFIRMED |
| IPinfo_1_3 with 8.8.8.8 | CONFIRMED at Cortex job level |
| TestAnalyzer | CONFIRMED, mixed outcomes |
| Human approve/reject handler | CONFIRMED at Flask layer |
| Simulated response | IMPLEMENTED |
| TheHive update | CONFIRMED |
| MailHog notification | CONFIRMED |
| One uninterrupted E2E run | **NOT PROVEN** |
| Real containment | **NOT PROVEN / intentionally simulated** |
| External email delivery | **NOT PROVEN** |

### Recommended final acceptance test

Use a fresh TheHive case containing exactly one known IP Observable and capture:

```text
Case ID
Observable ID
Observable value
Shuffle execution ID
TheHive query response
mapped value
Cortex job ID
analyzer name
job status
result body
analyst decision
response branch
TheHive update
MailHog message
```

That would provide deterministic E2E evidence.

## 20. Troubleshooting

| Issue | Evidence | Root Cause / Interpretation | Action | Result |
|---|---|---|---|---|
| Docker socket permission denied | E-58 | Current user lacked permission to access Docker socket | Service/admin permission troubleshooting | Later Docker commands executed |
| Webhook uninitialized | E-19, E-21 | Shuffle webhook trigger was not initialized | Inspect trigger configuration / runtime | Troubleshooting continued |
| Orborus/no results | E-23 | Workflow execution depended on Orborus | Inspect Orborus/workers and rerun | Later executions returned results |
| Cortex responder rights | E-38 | API request reached Cortex but privileged operation was rejected | Validate organization/role context | Permission issue isolated |
| Cortex context | E-39, command history | Correct `/cortex` context required | Update TheHive Cortex server config | HTTP 200 + config update log |
| Analyzer discovery | E-16, E-24, E-63 | Analyzer definition had to be inspected/created locally | Inspect local definitions/catalog | IPinfo compatibility path established |
| TestAnalyzer failures | E-48, E-54 | Repeated jobs had mixed results | Inspect job history/logs | One success + two failures visible |
| SMTP connection refused | E-34 | Mailer could not connect to SMTP sink at that point | Deploy/test MailHog and connectivity | Later MailHog email received |
| Dynamic mapping | E-8 | Nested/array JSON response | Inspect actual body structure | Final documented mapping set to `$thehive_2.body.0.data`; screenshot discrepancy retained |
| Cached/stale result risk | workflow history | Job/result status can be separated from current input | Correlate fresh job IDs and result body | Required for final E2E acceptance |

## 21. Security Considerations

### Credentials

The project evidence contains credential material in terminal history/screenshots. The publication package therefore:

- redacts visible credential values,
- excludes the raw terminal history,
- excludes the source PDF containing unredacted credential material,
- uses `<REDACTED>` in documentation.

Any credential visible in the original evidence should be considered exposed and rotated.

### Webhooks

Production deployment should use:

- authentication/signatures,
- TLS,
- network restrictions,
- replay protection,
- rate limiting,
- payload validation.

### Service accounts

Use least-privilege accounts for:

- TheHive API,
- Cortex API,
- Shuffle integrations,
- SMTP/notification.

### Response safety

The containment branch remains simulated. Production response should require explicit authorization, change control, and rollback procedures.

## 22. Validation Matrix

| Tool | Test | Expected | Observed | Status | Evidence |
|---|---|---|---|---|---|
| TheHive | UI availability | Login/case UI reachable | Visible | CONFIRMED | E-57 |
| TheHive | Case creation | SOAR test case exists | Visible | CONFIRMED | E-43–E-45 |
| TheHive | IP Observable | IP artifact exists | Visible | CONFIRMED | E-44, E-46 |
| TheHive | Cortex connector | Config accepted | HTTP 200 + update log | CONFIRMED | E-39 |
| Shuffle | Workflow | `SOC-Auto-Response` exists | Visible | CONFIRMED | E-8, E-31 |
| Shuffle | TheHive authentication | API key + instance URL | Config visible | IMPLEMENTED | E-27 |
| Shuffle | Cortex action | HTTP 200 | `status: 200`, `success: true` | CONFIRMED | E-9, E-11 |
| TheHive query | Case + Observables | JSON response | Query exercised in history | PARTIALLY VERIFIED | Command history |
| Dynamic mapping | Extract intended IP | `8.8.8.8` | Final project expression documented; screenshot shows `[1]` | PARTIALLY VERIFIED | E-8 |
| Cortex | IPinfo_1_3 | Successful job for IP | `8.8.8.8`, `Success` | CONFIRMED | E-16 |
| Cortex | TestAnalyzer_1_0 | Job execution | 1 success + 2 failures | CONFIRMED / MIXED | E-48, E-54 |
| HITL | Approve | Decision received | Flask logs show approve | CONFIRMED | E-10 |
| HITL | Reject | Decision received | Flask logs show reject | CONFIRMED | E-12 |
| Response | Containment | Simulated only | No real action evidenced | IMPLEMENTED / NOT PROVEN | E-7 |
| TheHive update | Tag/update | Case changes | Mail tag visible | CONFIRMED | E-41 |
| Mailer | Responder present | Mailer available | `Mailer_1_0` visible | CONFIRMED | E-42 |
| MailHog | Notification | Message received | SOAR test email visible | CONFIRMED | E-35 |
| Full E2E | One correlated run | All stages linked | No single continuous proof | NOT PROVEN | — |

## 23. Evidence Index

The supplied PDF contains **67 evidence pages**. Each page is preserved as `E-01.jpg` through `E-67.jpg` in the final package.

The detailed index and caption set are provided separately in:

```text
Evidence_Index.md
Screenshot_Notes.md
```

## 24. Lessons Learned

### API context is part of the integration contract

A service can be reachable while the API endpoint is still wrong. `/cortex` and `/thehive` context paths must be validated explicitly.

### HTTP success is not semantic success

A `200` response proves transport/API-level success. It does not prove that the intended Observable was analyzed or that useful enrichment was returned.

### JSON arrays require deterministic selection

If the query returns:

```text
1.1.1.1
8.8.8.8
```

an index such as `[0]` cannot be treated as a permanent identity for the target Observable.

### Cache state matters

A cached result can hide whether the current dynamic input was actually processed. Fresh job IDs and result bodies should be correlated.

### Mixed job history is valuable evidence

The TestAnalyzer history shows both successful and failed jobs. This is more useful for engineering than presenting only the green execution.

### Human approval is a control boundary

The analyst decision prevents a lab workflow from becoming an uncontrolled autonomous response mechanism.

### Credential hygiene must be part of evidence handling

Terminal screenshots are evidence, but they can also become an accidental credential-distribution mechanism. Sanitization and rotation are part of the technical workflow.

## 25. Conclusion

Operation Autopilot demonstrates the practical engineering required to integrate TheHive, Cortex, and Shuffle into a SOC-oriented orchestration workflow.

The project is strongest where it treats integration as a validation problem rather than assuming that a green HTTP response means the workflow is correct. The evidence captures real troubleshooting around Docker permissions, Cortex authorization, API context, analyzer availability, SMTP connectivity, webhook state, JSON mapping, and mixed analyzer results.

The lab supports a professional portfolio claim of:

> **A lab-scale SOAR integration implementing case-driven Observable retrieval, Cortex enrichment, analyst decision handling, simulated response, case updates, and isolated notification testing.**

It should not currently be described as a fully verified production-grade autonomous response system.

The remaining engineering task is a clean, single-run E2E acceptance test with correlation IDs across every stage. That test would close the principal evidence gap and make the workflow auditable from Observable ingestion through final notification.
