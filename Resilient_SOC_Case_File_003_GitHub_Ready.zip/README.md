# Resilient SOC Case File #003 — Operation Autopilot

Evidence-driven SOAR case study package.

## Stack
- TheHive 5.7.5
- Cortex 4.1.0
- Shuffle
- Elasticsearch 8.19.20
- Cassandra 4.1.12
- Nginx 1.31.4 (shown in evidence)
- MailHog
- Kali Linux
- Docker 28.5.2+dfsg4
- Docker Compose 2.40.3-3

## Workflow
TheHive → Shuffle → TheHive Query → Observable Retrieval → Dynamic Mapping → Cortex → Analyzer → Analysis → Human Decision → Simulated Response → TheHive Update → Notification

## Evidence posture
The package uses:
- CONFIRMED
- IMPLEMENTED
- PARTIALLY VERIFIED
- NOT PROVEN

The final E2E chain is intentionally not claimed as fully proven because the supplied evidence does not contain one uninterrupted, correlation-preserving execution.

## Main files
- `Documentation/Case_File_003_Operation_Autopilot.md`
- `Evidence_Index.md`
- `Screenshot_Notes.md`
- `Commands_Reference.md`
- `Team_Handoff.md`
- `Validation_Matrix.md`
- `Case_File_003_Operation_Autopilot.pdf`
- `Evidence/Screenshots/E-01.jpg` … `E-67.jpg`

## Security
The original evidence contained credential material. The publication package redacts visible secrets and excludes the raw terminal history and unredacted source PDF.
