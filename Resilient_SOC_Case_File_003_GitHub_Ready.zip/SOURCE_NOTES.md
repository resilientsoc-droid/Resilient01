# Source Notes

Inputs reviewed for this package:

1. The supplied 67-page evidence PDF.
2. The uploaded `Resilient_SOC_Case_File_003.zip`.
3. The project ZIP's documentation, completion checklist, evidence index, sanitized terminal history, and command history.

The uploaded project ZIP does not contain the actual Docker Compose/configuration source tree; it contains documentation/evidence and terminal history. Therefore reproducibility from the ZIP alone is **partial**. The command history provides the missing implementation trail.

The final package intentionally excludes:
- raw terminal history,
- unredacted source PDF,
- unredacted screenshots.

The final evidence images are publication-sanitized copies of the 67 PDF pages.
