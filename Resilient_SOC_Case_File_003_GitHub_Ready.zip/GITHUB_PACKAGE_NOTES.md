# GitHub Package Notes

This repository package intentionally excludes the standalone raw evidence PDF and the extracted screenshot set because the primary case PDF and documentation already preserve the case record needed for review.

The exclusions reduce repository size while keeping the main report, documentation, command references, validation material, architecture diagram, and handoff notes.
