# Resilient SOC Case File #003 — Operation Autopilot

> **Evidence-driven SOAR integration lab | TheHive + Cortex + Shuffle + Splunk**

## Overview

**Operation Autopilot** is a defensive Security Operations Center (SOC) lab built to demonstrate how a security case can move from detection and investigation into orchestration, enrichment, analyst decision-making, simulated response, case tracking, and notification.

The project intentionally follows an **evidence-first approach**. Every stage is classified as **CONFIRMED**, **IMPLEMENTED**, **PARTIALLY VERIFIED**, or **NOT PROVEN** instead of assuming that a configured workflow automatically means a successful end-to-end execution.

The result is a realistic lab that demonstrates strong component-level integration while clearly identifying the remaining validation gap for one uninterrupted, correlation-preserving E2E run.

---

## Project Goals

The main objectives were to:

1. Build a small SOC/SOAR environment using containerized services.
2. Manage security cases and Observables in TheHive.
3. Integrate TheHive with Cortex for analysis and enrichment.
4. Use Shuffle as the orchestration layer.
5. Retrieve Observables from TheHive dynamically instead of hard-coding analysis input.
6. Execute Cortex analyzers and inspect their results.
7. Introduce a Human-in-the-Loop (HITL) decision point.
8. Simulate a response path without performing real production containment.
9. Update the originating TheHive case.
10. Deliver a lab notification through MailHog.
11. Preserve troubleshooting and validation evidence throughout the process.

---

## Architecture

![Architecture](Documentation/architecture.png)

### Logical flow

```text
                    +-------------------+
                    |      Splunk       |
                    | Detection Context |
                    +---------+---------+
                              |
                              v
                    +-------------------+
                    |      TheHive      |
                    | Case + Observable |
                    +---------+---------+
                              |
                              v
                    +-------------------+
                    |      Shuffle      |
                    |   Orchestration   |
                    +----+---------+----+
                         |         |
             Query/Map   |         | Decision
                         v         v
                +--------+--+   +--+----------------+
                | TheHive   |   | Flask HITL Handler |
                | API       |   | approve / reject   |
                +-----------+   +--------------------+
                         |
                         | mapped Observable
                         v
                  +------+-------+
                  |    Cortex    |
                  | Analyzer API |
                  +------+-------+
                         |
                         v
                  +------+-------+
                  | Analyzer Job |
                  | IPinfo / Test|
                  +------+-------+
                         |
              +----------+-----------+
              |                      |
              v                      v
       Simulated Response      TheHive Update
                                      |
                                      v
                                  MailHog
```

### Component responsibilities

| Component | Role |
|---|---|
| **Splunk** | SIEM / detection and investigation context |
| **TheHive 5.7.5** | Case and Observable management |
| **Cortex 4.1.0** | Analyzer and responder execution |
| **Shuffle** | SOAR orchestration |
| **Flask webhook** | Human analyst decision boundary |
| **Elasticsearch 8.19.20** | Supporting search/storage dependency |
| **Cassandra 4.1.12** | TheHive dependency |
| **MailHog** | Isolated notification sink |
| **Nginx** | Lab web/proxy component shown in the environment |
| **Kali Linux** | Administration, testing and troubleshooting |
| **Docker / Compose** | Containerized deployment |

---

## Technology Stack

```text
TheHive       5.7.5
Cortex        4.1.0
Elasticsearch 8.19.20
Cassandra     4.1.12
Docker        28.5.2+dfsg4
Compose       2.40.3-3
Shuffle       Lab deployment
MailHog       Lab deployment
Kali Linux    Host / administration
Nginx         1.31.4 (shown in environment evidence)
```

---

# 1. Detection Context

The wider SOC lab provides endpoint and SIEM telemetry that can be used as the investigation starting point.

Examples captured in the evidence include:

- **Windows Security EventCode 4907** searches for policy-change activity.
- **Windows Security EventCode 4688** process-creation searches for PowerShell, command shells, and archive tooling.
- **Sysmon EventCode 11** telemetry for ZIP/archive creation, including a visible `Suspicious Archive Creation` alert.

These searches demonstrate that the environment is not only an orchestration demo: there is also a detection/investigation context feeding the case-management layer.

The detection layer and SOAR layer are intentionally treated as separate concerns: detection identifies suspicious activity, while SOAR coordinates the downstream case workflow.

---

# 2. TheHive Case Management

TheHive acts as the system of record for the investigation.

A test case named **`SOAR Test Case`** was created and used as the source case for the automation workflow. The case contains IP Observables, and the evidence confirms that the TheHive UI was reachable and the relevant case/Observable records existed.

The project also validated the TheHive status endpoint repeatedly during troubleshooting and integration work.

### Key evidence

- TheHive UI availability: **CONFIRMED**
- `SOAR Test Case`: **CONFIRMED**
- IP Observable: **CONFIRMED**
- TheHive API integration: **EXERCISED**

---

# 3. TheHive ↔ Cortex Integration

TheHive was configured to communicate with Cortex using the Cortex API context:

```text
http://cortex:9001/cortex
```

The environment also used the host-facing Cortex endpoint:

```text
http://192.168.1.11:9001/cortex
```

The project evidence contains a successful configuration update with HTTP `200` and the log message:

```text
cortex.servers config was updated
```

This confirms that the TheHive-side Cortex connector configuration was accepted by the application.

### Status

**CONFIRMED**

### Important security note

API authentication was handled with Bearer credentials during the lab. The original evidence contained credential material, so publication copies redact secrets and exclude the raw terminal history and unredacted source material.

---

# 4. Cortex Analyzer Validation

## 4.1 TestAnalyzer_1_0

`TestAnalyzer_1_0` was used to validate the analyzer execution path.

The captured job history shows both successful and failed runs:

```text
1 successful execution
2 failed executions
```

This is intentionally reported as a **mixed outcome** rather than presenting the analyzer as universally healthy.

### What this proves

- Cortex analyzer execution was exercised.
- At least one `TestAnalyzer_1_0` job succeeded.
- Other attempts failed.
- The execution path is functional but not proven to be 100% reliable.

---

# 5. IPinfo Analyzer Investigation

The workflow required IP enrichment, so the project inspected the local Cortex analyzer definitions and created a lab-local compatibility/alias definition for:

```text
IPinfo_1_3
```

The local definition was renamed from the existing IPinfo definition rather than being treated as a newly authored upstream analyzer.

The most important evidence is the successful Cortex job showing:

```text
analyzerName: IPinfo_1_3
data: 8.8.8.8
organization: Resilient-SOC
status: Success
```

### Conclusion

The lab-local `IPinfo_1_3` analyzer definition was successfully executed by Cortex against `8.8.8.8`.

### Status

**CONFIRMED — at Cortex job level**

---

# 6. Shuffle as the SOAR Layer

Shuffle provides the orchestration layer that connects the individual services.

The intended workflow is:

```text
TheHive Case
    ↓
Observable Retrieval
    ↓
Dynamic Mapping
    ↓
Cortex Analysis
    ↓
HITL Decision
    ↓
Simulated Response
    ↓
TheHive Update
    ↓
Notification
```

The main workflow is named:

```text
SOC-Auto-Response
```

The evidence also shows an early `Repeat back to me` / `Hello world` smoke test. This is correctly treated as an orchestration smoke test rather than as proof of the final production-style workflow.

---

# 7. Shuffle → TheHive Integration

Shuffle was configured to communicate with TheHive using API-key authentication and the lab TheHive instance.

The integration was exercised through the TheHive `/api/v1` API namespace.

The workflow design retrieves the case and its Observables from TheHive instead of relying only on static input.

### Status

**IMPLEMENTED / EXERCISED**

---

# 8. Dynamic Observable Retrieval

A central requirement of the workflow was to obtain the IP Observable dynamically from TheHive.

The query used the TheHive API endpoint:

```text
/thehive/api/v1/query
```

with a query structure based on:

```json
{
  "query": [
    {
      "_name": "getCase",
      "idOrName": "~122884224"
    },
    {
      "_name": "observables"
    }
  ]
}
```

The project history confirms direct testing of case/Observable retrieval, including filtering for the target IP `8.8.8.8`.

The purpose of this design is important: the Cortex input should come from the current case data rather than from a hard-coded IP.

---

# 9. Dynamic Mapping Problem and Validation Gap

This was the most important technical validation issue discovered in the project.

The Shuffle Cortex custom action screenshot visibly shows:

```text
$thehive_2.body[1].data
```

while the project documentation identifies the intended final expression as:

```text
$thehive_2.body.0.data
```

The two expressions are not interchangeable when the response contains multiple Observables.

The project notes that the query response can contain multiple values such as:

```text
1.1.1.1
8.8.8.8
```

Therefore, array indexing is execution-dependent.

### Correct production-minded design

Instead of relying blindly on an array position, the workflow should select the correct Observable using explicit attributes such as:

```text
datatype == ip
AND
data == expected value
```

or otherwise validate that the selected object is the intended one before sending it to Cortex.

### Evidence classification

| Item | Status |
|---|---|
| Dynamic mapping concept | **IMPLEMENTED** |
| TheHive query | **EXERCISED** |
| Intended final expression | **DOCUMENTED** |
| Exact final mapping used in the successful IPinfo run | **PARTIALLY VERIFIED** |
| Cortex receiving `8.8.8.8` | **CONFIRMED** |

This discrepancy is intentionally preserved in the public write-up rather than silently edited away.

---

# 10. Shuffle → Cortex Execution

The Shuffle Cortex action was validated at the HTTP layer.

Observed execution values include:

```text
status: 200
success: true
```

This demonstrates successful HTTP interaction with Cortex.

However:

```text
HTTP 200
≠
validated semantic enrichment result
```

A successful HTTP response only proves that the request reached the target and was accepted. The final enrichment must still be correlated to the exact Observable and Cortex job.

### Status

**CONFIRMED — HTTP level**

---

# 11. Cortex Job Correlation

The project history includes direct Cortex job inspection and report retrieval attempts.

The strongest IP enrichment evidence is the `IPinfo_1_3` job showing:

```text
8.8.8.8 → Success
```

This proves the Cortex analyzer layer worked for the target input.

What is **not** independently demonstrated by the supplied material is a single, uninterrupted chain connecting:

```text
TheHive case
→ exact Shuffle execution
→ exact mapped Observable
→ exact Cortex job ID
→ analysis result
→ analyst decision
→ response branch
→ TheHive update
→ notification
```

That distinction is central to the evidence posture of this project.

---

# 12. Human-in-the-Loop (HITL)

The lab introduces a human decision boundary through a custom Flask service:

```text
soar_webhook.py
```

running on:

```text
127.0.0.1:5000
```

Both decision paths were explicitly exercised:

```json
{"action":"approve"}
```

and:

```json
{"action":"reject"}
```

The handler logs show the decision values being received and processed.

### What this proves

The decision handler itself is functioning.

### What it does not prove

The evidence does not prove that a single complete Shuffle execution paused, waited for the analyst, and then resumed through this handler all the way to the final response branch.

### Status

**CONFIRMED — handler layer**

---

# 13. Simulated Response

The response design is intentionally safe for a lab environment:

```text
Approve → Simulated Containment
Reject  → Escalation
```

No real endpoint isolation, firewall blocking, user disabling, or other production-side containment is claimed.

This is an important safety boundary: the project demonstrates response orchestration without granting the lab workflow uncontrolled production authority.

### Status

**IMPLEMENTED — simulation only**

---

# 14. TheHive Case Update

The originating TheHive case contains a visible update tag:

```text
mail=soc01@resilient.local
```

The project history also includes direct tag/update API activity.

This confirms that the case can be updated by the workflow.

The supplied evidence does not establish that this exact update occurred immediately after the exact successful IPinfo job in the same correlated run.

### Status

**CONFIRMED — case update**

---

# 15. Notification with MailHog

The lab uses MailHog as an isolated SMTP sink so notifications can be tested without external mail delivery.

The environment exposes the Cortex `Mailer_1_0` responder, and the project history shows SMTP troubleshooting followed by a successful notification path.

An intermediate failure was observed:

```text
ConnectionRefusedError [Errno 111] Connection refused
```

Later evidence shows a successful Mailer job and a visible MailHog message:

```text
[Case #1] SOAR Test Case
```

### Status

**CONFIRMED — lab notification**

External production email delivery is intentionally **NOT PROVEN**.

---

# 16. Troubleshooting Journey

One of the strongest aspects of the project is that the troubleshooting process itself was documented rather than hidden.

| Issue | Interpretation | Result |
|---|---|---|
| Docker socket permission denied | User lacked access to Docker socket | Permissions/admin path investigated |
| Shuffle webhook uninitialized | Trigger had not been initialized | Workflow configuration troubleshooting continued |
| Orborus/no-results state | Workflow depended on the worker/orchestration path | Worker/runtime troubleshooting continued |
| Cortex responder permissions | Request reached Cortex but privileged action was restricted | Organization/role context investigated |
| Cortex API context | `/cortex` context was required | TheHive connector updated successfully |
| Analyzer discovery | Local analyzer definitions required inspection | IPinfo compatibility path established |
| TestAnalyzer failures | Analyzer runs had mixed outcomes | One success + two failures captured |
| SMTP connection refused | Notification sink unavailable at that moment | MailHog deployed/tested successfully |
| Dynamic mapping | Nested/array response required extraction | Mapping was refined and discrepancy documented |

This mirrors real SOC engineering work: integration failures are expected, and the important part is isolating the fault domain and preserving evidence.

---

# 17. Validation Matrix

| Component | Test | Expected | Observed | Status |
|---|---|---|---|---|
| TheHive | UI availability | Reachable | Visible | **CONFIRMED** |
| TheHive | SOAR case | Case exists | `SOAR Test Case` visible | **CONFIRMED** |
| TheHive | IP Observable | IP artifact exists | Visible | **CONFIRMED** |
| TheHive | Cortex connector | Config accepted | HTTP 200 + update log | **CONFIRMED** |
| Shuffle | Main workflow | `SOC-Auto-Response` | Exists / runs | **CONFIRMED** |
| Shuffle | TheHive auth | API key + URL | Configuration present | **IMPLEMENTED** |
| Shuffle | Cortex action | HTTP success | `status: 200`, `success: true` | **CONFIRMED** |
| TheHive API | Case + Observable query | JSON returned | Exercised in command history | **PARTIALLY VERIFIED** |
| Dynamic mapping | Correct IP selection | `8.8.8.8` | Intended expression documented; screenshot differs | **PARTIALLY VERIFIED** |
| Cortex | `IPinfo_1_3` | Successful job | `8.8.8.8`, `Success` | **CONFIRMED** |
| Cortex | `TestAnalyzer_1_0` | Successful execution | Mixed success/failure | **CONFIRMED / MIXED** |
| HITL | Approve | Decision received | Flask handler tested | **CONFIRMED** |
| HITL | Reject | Decision received | Flask handler tested | **CONFIRMED** |
| Response | Containment | Simulated | No real action evidenced | **IMPLEMENTED / NOT PROVEN** |
| TheHive | Case update | Case changed | Tag/update visible | **CONFIRMED** |
| Cortex | Mailer responder | Responder available | `Mailer_1_0` visible | **CONFIRMED** |
| MailHog | Notification | Message received | SOAR test message visible | **CONFIRMED** |
| Full E2E | One correlated run | Entire chain in one execution | Not demonstrated | **NOT PROVEN** |

---

# 18. Evidence Classification

The project uses the following evidence model:

### CONFIRMED

Directly demonstrated by screenshots, logs, UI state, or job output.

### IMPLEMENTED

Present in configuration or workflow design and exercised to some degree, but not independently proven as a complete result.

### PARTIALLY VERIFIED

Some portion of the behavior is demonstrated, but an important correlation or final-state condition is missing.

### NOT PROVEN

The available evidence is insufficient to claim the result.

This classification is deliberately conservative and avoids confusing configuration with successful execution.

---

# 19. Security Considerations

## Credential exposure

The original working material contained credential material during troubleshooting. Those values should be treated as exposed and rotated.

The publication package therefore:

- redacts visible secrets,
- excludes raw terminal history,
- excludes the unredacted source PDF,
- uses placeholders such as `<REDACTED>` in documentation.

## API security

Production deployments should use:

- TLS,
- scoped service accounts,
- least-privilege API keys,
- secret storage outside workflow definitions,
- payload validation,
- webhook authentication/signatures,
- replay protection,
- rate limiting.

## Response safety

Production containment should require explicit authorization, change control, rollback procedures, and strong auditability.

The current lab intentionally keeps the containment stage simulated.

---

# 20. Final E2E Acceptance Test

The remaining validation gap can be closed with one deterministic fresh run.

Create a new TheHive case with **exactly one known IP Observable** and capture the following chain in one execution:

```text
Case ID
Observable ID
Observable value
Shuffle execution ID
TheHive query response
Mapped value
Cortex job ID
Analyzer name
Analyzer result
Analyst decision
Response branch
TheHive update
MailHog message
```

The most important improvement is to correlate the identifiers across systems rather than relying on screenshots from separate runs.

For the Observable selection step, prefer attribute-based selection over a hard-coded array index.

---

# 21. Current Assessment

## Overall

**Implemented with partial end-to-end verification.**

### Strongly demonstrated

- TheHive case management
- IP Observable handling
- TheHive ↔ Cortex configuration
- Cortex analyzer execution
- Successful `IPinfo_1_3` enrichment for `8.8.8.8`
- Shuffle workflow presence and execution
- HITL approve/reject handler
- TheHive case update
- MailHog notification
- Detection-context telemetry in Splunk

### Still not fully proven

- One uninterrupted, correlation-preserving E2E execution
- Exact final dynamic-mapping expression used in the successful IPinfo run
- Real production containment
- External email delivery

---

# 22. Lessons Learned

### 1. HTTP success is not workflow success

A `200 OK` response proves transport-level success, not semantic correctness.

### 2. Array indexing is fragile

SOAR workflows should validate the intended Observable instead of assuming the correct object is always at index `0` or `1`.

### 3. Evidence quality matters as much as implementation

A workflow can be technically functional while still lacking enough evidence to prove a complete E2E chain.

### 4. Lab-safe automation is better than uncontrolled automation

The simulated containment branch provides a realistic SOAR decision flow without risking real infrastructure.

### 5. Troubleshooting should remain part of the record

Docker permissions, worker availability, API context, analyzer behavior, SMTP availability, and payload mapping were all part of the engineering story and were preserved as traceability evidence.

---

# 23. Repository Structure

```text
.
├── README.md
├── WRITEUP.md
├── COMPLETED_TASKS.md
├── Validation_Matrix.md
├── Evidence_Index.md
├── Screenshot_Notes.md
├── Commands_Reference.md
├── Team_Handoff.md
├── Documentation/
│   ├── Case_File_003_Operation_Autopilot.md
│   └── architecture.png
├── Commands/
│   └── Case_003_Terminal_History_REDACTED.txt
├── Configuration/
│   └── Sanitized_Configurations/
└── Evidence/
    └── Screenshots/
        ├── E-01.jpg
        ├── ...
        └── E-67.jpg
```

---

# 24. Conclusion

Operation Autopilot demonstrates a practical SOC automation architecture in which **TheHive manages the investigation, Shuffle orchestrates the workflow, Cortex performs analysis, the analyst retains decision authority, and the case is updated and notified through controlled lab services**.

The project is strongest where it stays evidence-driven: successful integrations are shown directly, mixed analyzer results are reported honestly, and the remaining E2E gap is explicitly documented instead of being hidden.

The next milestone is not adding more components. It is producing **one fresh, fully correlated acceptance run** that proves the entire chain from Observable retrieval through enrichment, analyst decision, response branch, TheHive update, and notification.

---

## Evidence References

The repository contains the detailed evidence index and screenshot notes used to support this write-up:

- [`Evidence_Index.md`](Evidence_Index.md)
- [`Screenshot_Notes.md`](Screenshot_Notes.md)
- [`Validation_Matrix.md`](Validation_Matrix.md)
- [`Team_Handoff.md`](Team_Handoff.md)
- [`Documentation/Case_File_003_Operation_Autopilot.md`](Documentation/Case_File_003_Operation_Autopilot.md)
